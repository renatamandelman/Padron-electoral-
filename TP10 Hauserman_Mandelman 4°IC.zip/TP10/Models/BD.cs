using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using Dapper;
using System;

 namespace TP10.Models{

      public static class bd{
     
          // DESKTOP-BI67781

        private static string _connectionString=@"Server=A-LUM-12;DataBase=BDPadron;Trusted_Connection=True;";

        public static persona ConsultaPadron(int dni){

            Console.WriteLine(dni);
            persona pers=null;
            using(SqlConnection db = new SqlConnection(_connectionString)){
                
                string sql=$"SELECT * FROM Personas WHERE Personas.DNI={dni}";
                pers=db.QueryFirstOrDefault<persona>(sql);
            }

            return pers;
        }

        public static establecimiento ConsultaEstablecimiento(int idEstablecimiento){
            establecimiento est;
            //recibimos id desde 1
            using(SqlConnection db = new SqlConnection(_connectionString)){
            string sql=$"SELECT * FROM Establecimiento WHERE Establecimiento.IdEstablecimiento={idEstablecimiento}";
            est=db.QueryFirstOrDefault<establecimiento>(sql);
            }
            return est;
        }

        public static bool Votar(int dni, int tramite){
            bool votoRealizado;
            int seCambio;
            using(SqlConnection db = new SqlConnection(_connectionString)){
            string sql=$"UPDATE Personas SET voto=1 WHERE Personas.DNI=@pdni AND Personas.NumeroTramite={tramite}";
            seCambio=db.Execute(sql, new{pdni=dni, ptramite=tramite});
            }
            if(seCambio>0){
                votoRealizado=true;
            }
                else{
                    votoRealizado=false;
                }
            
            return votoRealizado;
        }

        public static bool yaVoto(int dni){
            dynamic voto;

            using(SqlConnection db = new SqlConnection(_connectionString)){
            string sql=$"SELECT Personas.Voto FROM Personas WHERE DNI={dni}";
            voto=db.Query(sql);
            }

            return voto;
        }

      }
 }
 

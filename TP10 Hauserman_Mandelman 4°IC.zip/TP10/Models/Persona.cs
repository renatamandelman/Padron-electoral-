using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using Dapper;

 namespace TP10.Models{

     public class persona{
         private  int _dni;
          private string _apellido;
          private string _nombre;
        private int _nroTramite;
         private int _idEstablecimiento;
        private bool _voto;

     public int Dni{
            get{
                return _dni;
            }
            set{
                 _dni = value;
            }
        }
     public string Apellido{
            get{
                return _apellido;
            }
            set{
                 _apellido =value;
            }
        }

         public string Nombre{
            get{
                return _nombre;
            }
            set{
                 _nombre = value;
            }
        }

         public int NumeroTramite{
            get{
                return _nroTramite;
            }
            set{
                 _nroTramite = value;
            }
        }
         public int IdEstablecimiento{
            get{
                return _idEstablecimiento;
            }
            set{
                 _idEstablecimiento = value;
            }
        }
         public bool Voto{
            get{
                return _voto;
            }
            set{
                 _voto = value;
            }
        }
        
        
     }

     
 }

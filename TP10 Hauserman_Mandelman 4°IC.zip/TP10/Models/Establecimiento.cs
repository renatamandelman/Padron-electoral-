using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using Dapper;

 namespace TP10.Models{

     public  class establecimiento{
        private int _idEstablecimiento;
        private string _nombre;
        private string _direccion;
        private string _localidad;

        public int IdEstacionamiento{
        get{
            return _idEstablecimiento;

        }

        set{
            _idEstablecimiento=value;
        }
    }
    
    public string Nombre{
        get{
            return _nombre;

        }

        set{
            _nombre=value;
        }
    }

    public string Direccion{
        get{
            return _direccion;

        }

        set{
            _direccion=value;
        }
    }

    public string Localidad{
        get{
            return _localidad;

        }

        set{
            _localidad=value;
        }
    }

    }
    
     
 }

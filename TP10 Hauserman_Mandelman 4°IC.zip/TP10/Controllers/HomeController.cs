﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TP10.Models;

namespace TP10.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }


        [HttpPost] public IActionResult ConsultaPadron(int dni)
        {

            persona pers=bd.ConsultaPadron(dni);

            ViewBag.persona=pers;
            if(pers==null){
                ViewBag.resultado="noexiste";
                return View("index");
            }

            else if(pers.Voto==true){
                ViewBag.resultado="yaVoto";

                return View("votar");
            }

            else{
                ViewBag.resultado="noVoto";
                Console.WriteLine("no voto");
                return View("votar");
            }

        }

        [HttpPost] public IActionResult VotarForm(int dni, int numeroTramite)
        {   
            Console.WriteLine(dni);
            persona pers=bd.ConsultaPadron(dni);
            bool voto;
            int tramite=pers.NumeroTramite;
            ViewBag.persona=pers;

            if(pers.NumeroTramite==numeroTramite){
                voto=bd.Votar(dni, numeroTramite);
                if(voto==true){
                    ViewBag.resultado="votoExitoso";
                }
                
                return View("index");
            }
                else{

                    ViewBag.resultado="votoFallido";
                    return View("votar");
                }
            
        }
        

      /*  [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }*/
    }
}
